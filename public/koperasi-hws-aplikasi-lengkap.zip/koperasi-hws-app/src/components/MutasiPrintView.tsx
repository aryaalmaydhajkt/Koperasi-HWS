import React, { useState } from 'react';
import { MemberUser, MemberTransaction } from '../types';
import { HwsLogo } from './HwsLogo';
import { formatNumberId } from '../utils/exportUtils';
import { ArrowLeft, Printer, Filter, Calendar } from 'lucide-react';

interface MutasiPrintViewProps {
  member: MemberUser;
  transactions: MemberTransaction[];
  periodeLabel?: string;
  filterKategori?: 'SEMUA' | 'POKOK' | 'UMUM';
  onBack: () => void;
}

export const MutasiPrintView: React.FC<MutasiPrintViewProps> = ({
  member,
  transactions,
  periodeLabel: initialPeriodeLabel = 'Semua Periode',
  filterKategori: initialFilterKategori = 'SEMUA',
  onBack,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<'SEMUA' | 'POKOK' | 'UMUM'>(initialFilterKategori);
  const [periodeType, setPeriodeType] = useState<'SEMUA' | 'HARIAN' | 'BULANAN' | 'TAHUNAN' | 'CUSTOM'>('SEMUA');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [selectedMonth, setSelectedMonth] = useState<string>(new Date().toISOString().slice(0, 7));
  const [selectedYear, setSelectedYear] = useState<string>(new Date().getFullYear().toString());
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');

  // Normalize date helper
  const isDateInFilter = (dateStr: string) => {
    if (periodeType === 'SEMUA') return true;
    let normalized = dateStr;
    if (dateStr.includes('/')) {
      const parts = dateStr.split('/');
      if (parts.length === 3) {
        normalized = `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
      }
    }
    if (periodeType === 'HARIAN') return normalized === selectedDate;
    if (periodeType === 'BULANAN') return normalized.startsWith(selectedMonth);
    if (periodeType === 'TAHUNAN') return normalized.startsWith(selectedYear);
    if (periodeType === 'CUSTOM') {
      if (dateFrom && normalized < dateFrom) return false;
      if (dateTo && normalized > dateTo) return false;
      return true;
    }
    return true;
  };

  const getPeriodeDisplay = () => {
    if (periodeType === 'HARIAN') return selectedDate;
    if (periodeType === 'BULANAN') return selectedMonth;
    if (periodeType === 'TAHUNAN') return selectedYear;
    if (periodeType === 'CUSTOM') return `${dateFrom || 'Awal'} s/d ${dateTo || 'Sekarang'}`;
    return initialPeriodeLabel;
  };

  const activePeriodeLabel = getPeriodeDisplay();

  // Filter by category and date
  const filteredTxs = transactions.filter((t) => {
    const matchDate = isDateInFilter(t.tanggal);
    if (!matchDate) return false;

    if (selectedFilter === 'POKOK') {
      return t.kategori === 'POKOK' || t.kategori === 'GABUNGAN_KEWAJIBAN';
    }
    if (selectedFilter === 'UMUM') {
      return t.kategori === 'UMUM';
    }
    return true;
  });

  // Keep chronological order (oldest to newest) per Point 55
  const sortedTxs = [...filteredTxs].sort((a, b) => {
    const parseDate = (d: string) => {
      const parts = d.split(/[-/]/);
      if (parts.length === 3) {
        if (parts[2].length === 4) return new Date(`${parts[2]}-${parts[1]}-${parts[0]}`).getTime();
        return new Date(d).getTime();
      }
      return 0;
    };
    return parseDate(a.tanggal) - parseDate(b.tanggal);
  });

  // Stats calculation
  let totalMasuk = 0;
  let countMasuk = 0;
  let totalKeluar = 0;
  let countKeluar = 0;

  sortedTxs.forEach((tx) => {
    if (tx.tipe === 'MASUK') {
      totalMasuk += tx.nominal;
      countMasuk++;
    } else {
      totalKeluar += tx.nominal;
      countKeluar++;
    }
  });

  const saldoAwal = 0.0;
  // Point 4.3: Total debit dan kredit sesuai periode tanggal yang ditentukan, jangan menggabungkan saldo akhir antara tabungan pokok dan tabungan umum
  const saldoAkhir = selectedFilter === 'POKOK'
    ? member.saldoPokok
    : selectedFilter === 'UMUM'
    ? member.saldoUmum
    : (member.saldoPokok + member.saldoUmum);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 py-6 px-4 print:p-0 print:bg-white print:text-black">
      
      {/* Control Toolbar - Hidden on Print */}
      <div className="max-w-[850px] mx-auto mb-6 bg-slate-800 border border-slate-700 p-4 rounded-2xl shadow-xl print:hidden space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-700">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-700 px-3 py-2 rounded-xl transition"
          >
            <ArrowLeft className="w-4 h-4" /> Kembali
          </button>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-mono">
              {sortedTxs.length} Mutasi Transaksi
            </span>
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-xl shadow-lg shadow-blue-500/20 transition"
            >
              <Printer className="w-4 h-4" /> Cetak / Unduh PDF Mutasi
            </button>
          </div>
        </div>

        {/* Filter Controls: Jenis Tabungan & Periode */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 text-xs">
          <div>
            <label className="block text-slate-400 mb-1">Jenis Tabungan:</label>
            <select
              value={selectedFilter}
              onChange={(e) => setSelectedFilter(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
            >
              <option value="SEMUA">Semua Tabungan</option>
              <option value="POKOK">Mutasi Tabungan Pokok</option>
              <option value="UMUM">Mutasi Tabungan Umum</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-400 mb-1">Periode:</label>
            <select
              value={periodeType}
              onChange={(e) => setPeriodeType(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white"
            >
              <option value="SEMUA">Seluruh Waktu</option>
              <option value="HARIAN">Harian (Pilih Tanggal)</option>
              <option value="BULANAN">Bulanan</option>
              <option value="TAHUNAN">Tahunan</option>
              <option value="CUSTOM">Rentang Tanggal</option>
            </select>
          </div>

          {periodeType === 'HARIAN' && (
            <div>
              <label className="block text-slate-400 mb-1">Tanggal:</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
              />
            </div>
          )}

          {periodeType === 'BULANAN' && (
            <div>
              <label className="block text-slate-400 mb-1">Bulan:</label>
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
              />
            </div>
          )}

          {periodeType === 'TAHUNAN' && (
            <div>
              <label className="block text-slate-400 mb-1">Tahun:</label>
              <input
                type="number"
                min="2020"
                max="2035"
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
              />
            </div>
          )}

          {periodeType === 'CUSTOM' && (
            <>
              <div>
                <label className="block text-slate-400 mb-1">Dari:</label>
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Sampai:</label>
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono"
                />
              </div>
            </>
          )}
        </div>
      </div>

      {/* Official Bank-Style Statement Paper (Matches image: "Cotoh mutasi anggota, logo ganti dengan logo HWS.png") */}
      <div className="max-w-[850px] mx-auto bg-white text-slate-900 border border-slate-300 p-8 shadow-2xl print:shadow-none print:border-none print:p-4 text-xs font-sans relative overflow-hidden">
        
        {/* Tiled Watermark Background - small & dense to prevent counterfeiting (Point D.1, F.3, 15) */}
        <div 
          className="absolute inset-0 pointer-events-none opacity-[0.045] z-0 select-none overflow-hidden"
          style={{
            backgroundImage: `radial-gradient(#1e3a8a 0.75px, transparent 0.75px), url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='110' height='70' viewBox='0 0 110 70'><g transform='rotate(-25 55 35)'><text x='10' y='30' font-family='Arial, sans-serif' font-size='10' font-weight='900' fill='%231e3a8a'>KOPERASI HWS</text><text x='25' y='44' font-family='Arial, sans-serif' font-size='7' font-weight='700' fill='%23b45309'>ORIGINAL</text></g></svg>")`,
            backgroundRepeat: 'repeat',
            backgroundPosition: '0 0, 0 0',
          }}
        />

        {/* Paper Content Layer */}
        <div className="relative z-10">
          
          {/* Top Header */}
          <div className="flex items-start justify-between pb-4 border-b border-black mb-4">
            <div className="flex items-center gap-3">
              <HwsLogo size={56} className="w-14 h-14" />
              <div>
                <div className="text-lg font-black tracking-tight text-blue-900 leading-tight">
                  KOPERASI HWS
                </div>
                <div className="text-[10px] uppercase font-bold text-slate-600">
                  KCP {member.wilayah.toUpperCase()}
                </div>
              </div>
            </div>

            <div className="text-center pt-2">
              <h1 className="text-xl font-bold tracking-wider text-slate-900">
                REKENING TAHAPAN
              </h1>
              <p className="text-[10px] text-slate-500 tracking-wide font-medium">
                MUTASI REKENING ANGGOTA RESMI
              </p>
            </div>

            <div className="w-20"></div> {/* spacer */}
          </div>

          {/* Address and Account Details Boxes */}
          <div className="grid grid-cols-2 gap-4 mb-4">
            {/* Box 1 (Left): Member Address (Tanpa alamat koperasi per point 22) */}
            <div className="border border-black p-3 rounded-sm leading-relaxed">
              <div className="font-bold text-[13px] uppercase tracking-wide">
                {member.nama}
              </div>
              <div className="text-[11px] uppercase font-semibold">
                KEC {member.wilayah}
              </div>
              <div className="text-[11px] uppercase">
                {member.rtRw ? `${member.rtRw}, ` : ''}{member.kelurahan ? `${member.kelurahan}, ` : ''}{member.alamat || 'JAKARTA'}
              </div>
              <div className="text-[11px] uppercase">
                {member.kota || 'JAKARTA BARAT'} {member.kodePos || '11740'}
              </div>
              <div className="text-[11px] uppercase font-semibold">
                INDONESIA
              </div>
            </div>

            {/* Box 2 (Right): Account Meta */}
            <div className="border border-black p-3 rounded-sm leading-relaxed font-mono">
              <div className="grid grid-cols-12 gap-1 text-[11px]">
                <span className="col-span-5 font-bold font-sans">NO. REKENING</span>
                <span className="col-span-1">:</span>
                <span className="col-span-6 font-bold">{member.noRekKoperasi}</span>

                <span className="col-span-5 font-bold font-sans">NO. ANGGOTA</span>
                <span className="col-span-1">:</span>
                <span className="col-span-6">{member.noAnggota}</span>

                <span className="col-span-5 font-bold font-sans">HALAMAN</span>
                <span className="col-span-1">:</span>
                <span className="col-span-6">1 / 1</span>

                <span className="col-span-5 font-bold font-sans">PERIODE</span>
                <span className="col-span-1">:</span>
                <span className="col-span-6 uppercase font-bold">{activePeriodeLabel}</span>

                <span className="col-span-5 font-bold font-sans">MATA UANG</span>
                <span className="col-span-1">:</span>
                <span className="col-span-6">IDR</span>
              </div>
            </div>
          </div>

          {/* Catatan Box */}
          <div className="border border-black p-2.5 rounded-sm mb-4 text-[9.5px] leading-tight bg-slate-50/50">
            <div className="font-bold mb-0.5">CATATAN:</div>
            <div className="grid grid-cols-2 gap-3 text-slate-700">
              <div>
                • Apabila anggota tidak melakukan sanggahan atas Laporan Mutasi Rekening ini sampai dengan akhir bulan berikutnya, anggota dianggap telah menyetujui segala data yang tercantum pada Laporan Mutasi Rekening ini.
              </div>
              <div>
                • Koperasi berhak setiap saat melakukan koreksi pembukuan apabila terdapat kesalahan pada Laporan Mutasi Rekening.
              </div>
            </div>
          </div>

          {/* Transaction Table */}
          <table className="w-full border-collapse border-y-2 border-black text-[10.5px]">
            <thead>
              <tr className="border-b border-black font-bold uppercase text-slate-800 text-[10px]">
                <th className="py-1.5 px-1 text-left w-16">TANGGAL</th>
                <th className="py-1.5 px-2 text-left">KETERANGAN</th>
                <th className="py-1.5 px-1 text-center w-12">CBG</th>
                <th className="py-1.5 px-2 text-right w-36">MUTASI</th>
                <th className="py-1.5 px-2 text-right w-36">SALDO</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {sortedTxs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400 italic font-mono">
                    Belum ada mutasi transaksi pada periode ini (Saldo 0).
                  </td>
                </tr>
              ) : (
                sortedTxs.map((tx) => (
                  <tr key={tx.id} className="align-top font-mono">
                    <td className="py-2 px-1 text-slate-900 font-medium">
                      {tx.tanggal.slice(0, 5)}
                    </td>
                    <td className="py-2 px-2 text-slate-900 font-sans">
                      <div className="font-bold text-[11px] text-slate-900 uppercase">
                        {tx.tipe === 'MASUK' ? 'TRSF MASUK CR' : 'TRSF KELUAR DB'}
                      </div>
                      <div className="text-[10px] text-slate-700 leading-snug">
                        {tx.keterangan}
                      </div>
                      {tx.rincian?.targetPenyaluran && (
                        <div className="text-[9px] text-slate-500 italic">
                          {tx.rincian.targetPenyaluran}
                        </div>
                      )}
                    </td>
                    <td className="py-2 px-1 text-center text-slate-600">
                      {tx.cbg || '0001'}
                    </td>
                    <td className="py-2 px-2 text-right tabular-nums font-semibold">
                      <span>{formatNumberId(tx.nominal)}</span>
                      <span className="ml-1 text-[10px] font-bold text-slate-600">
                        {tx.tipe === 'MASUK' ? 'CR' : 'DB'}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-right tabular-nums font-semibold text-slate-900">
                      {formatNumberId(tx.saldoSetelah)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          {/* Bottom Summary Box (Matches bank format) */}
          <div className="mt-8 flex justify-end">
            <div className="w-80 border-t border-black pt-3 font-mono text-[10.5px]">
              <div className="flex justify-between py-0.5">
                <span className="font-sans font-bold">SALDO AWAL :</span>
                <span className="tabular-nums">{formatNumberId(saldoAwal)}</span>
              </div>
              <div className="flex justify-between py-0.5">
                <span className="font-sans font-bold">MUTASI MASUK (CR) :</span>
                <div className="flex gap-4">
                  <span className="tabular-nums">{formatNumberId(totalMasuk)}</span>
                  <span className="w-8 text-right text-slate-500">{countMasuk}</span>
                </div>
              </div>
              <div className="flex justify-between py-0.5">
                <span className="font-sans font-bold">MUTASI KELUAR (DB) :</span>
                <div className="flex gap-4">
                  <span className="tabular-nums">{formatNumberId(totalKeluar)}</span>
                  <span className="w-8 text-right text-slate-500">{countKeluar}</span>
                </div>
              </div>
              {selectedFilter === 'SEMUA' ? (
                <>
                  <div className="flex justify-between py-1 border-t border-black font-bold text-amber-900">
                    <span className="font-sans">SALDO TABUNGAN KEWAJIBAN :</span>
                    <span className="tabular-nums">{formatNumberId(member.saldoPokok)}</span>
                  </div>
                  <div className="flex justify-between py-1 font-bold text-blue-900">
                    <span className="font-sans">SALDO TABUNGAN UMUM :</span>
                    <span className="tabular-nums">{formatNumberId(member.saldoUmum)}</span>
                  </div>
                </>
              ) : (
                <div className="flex justify-between py-1 border-t border-black font-bold">
                  <span className="font-sans">
                    SALDO AKHIR {selectedFilter === 'POKOK' ? '(TAB. KEWAJIBAN)' : '(TAB. UMUM)'} :
                  </span>
                  <span className="tabular-nums">{formatNumberId(selectedFilter === 'POKOK' ? member.saldoPokok : member.saldoUmum)}</span>
                </div>
              )}
            </div>
          </div>

          {/* Footer note: strictly NO signatures per prompt rules 19, 21, and 22 */}
          <div className="mt-8 pt-3 border-t border-dashed border-slate-300 text-[10px] text-slate-400 flex justify-between items-center font-mono">
            <span>Sistem Otomasi Koperasi HWS • Dicetak Tanpa Tanda Tangan Basah</span>
            <span>ID Dokumen: HWS-MUT-{member.noRekKoperasi}-{new Date().getFullYear()}</span>
          </div>

        </div>

      </div>

    </div>
  );
};
